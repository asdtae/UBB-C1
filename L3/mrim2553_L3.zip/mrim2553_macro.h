#ifndef L3_MRIM2553_MACRO_H
#define L3_MRIM2553_MACRO_H

#define STR "macro function"

#define add(x,y) ((x) + (y))

#endif //L3_MRIM2553_MACRO_H
