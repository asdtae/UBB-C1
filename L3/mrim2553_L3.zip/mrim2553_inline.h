#ifndef L3_MRIM2553_INLINE_H
#define L3_MRIM2553_INLINE_H

#define STR "inline function"

static inline long long int add(long long int numb1, long long int numb2)
{
    return (numb1 + numb2);
}

#endif //L3_MRIM2553_INLINE_H
